from django.urls import path
from . import views

urlpatterns = [
    path('', views.trang_chu, name='trang_chu'),
    path('khachhang/', views.khachhang_list, name='khachhang_list'),
    path('sanpham/', views.sanpham_list, name='sanpham_list'),
    path('loaihang/', views.loaihang_list, name='loaihang_list'),
    path('loaihang/<str:ma_loai>/', views.loaihang_detail, name='loaihang_detail'),
    path('taikhoan/', views.taikhoan_list, name='taikhoan_list'),
    path('donhang/', views.donhang_list, name='donhang_list'),
    path('quantri/sanpham/them/', views.them_san_pham, name='them_san_pham'),
    path('quantri/sanpham/sua/<str:ma_sp>/', views.sua_san_pham, name='sua_san_pham'),
    path('quantri/sanpham/xoa/<str:ma_sp>/', views.xoa_san_pham, name='xoa_san_pham'),
    path('quantri/taikhoan/them/', views.them_taikhoan, name='them_taikhoan'),
    path('quantri/taikhoan/sua/<str:ma_tk>/', views.sua_taikhoan, name='sua_taikhoan'),
    path('quantri/taikhoan/xoa/<str:ma_tk>/', views.xoa_taikhoan, name='xoa_taikhoan'),
    path('khachhang/them/', views.them_khachhang, name='them_khachhang'),
    path('quantri/khachhang/sua/<str:ma_kh>/', views.sua_khachhang, name='sua_khachhang'),
    path('quantri/khachhang/xoa/<str:ma_kh>/', views.xoa_khachhang, name='xoa_khachhang'),
    path('quantri/loaihang/them/', views.them_loaihang, name='them_loaihang'),
    path('quantri/loaihang/sua/<str:ma_loai>/', views.sua_loaihang, name='sua_loaihang'),
    path('quantri/loaihang/xoa/<str:ma_loai>/', views.xoa_loaihang, name='xoa_loaihang'),
]
